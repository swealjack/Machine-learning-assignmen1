package de.uniba.cogsys.ml.assignment1.tree;

public interface Node {
}
